# Export Instructions for NFC Payment System

This guide will walk you through the steps to export and install the NFC Payment System as a native Android app on your device to fully test the NFC functionality.

## Prerequisites

- An Android phone with NFC capabilities
- MacBook Air M1 (or any computer with Node.js)
- Expo account (sign up at [expo.dev](https://expo.dev))
- Expo Go app installed on your device (for development testing)

## Step 1: Setup Environment

1. Install Node.js if not already installed:
   ```bash
   # On Mac with Homebrew:
   brew install node
   
   # Or download from https://nodejs.org/
   ```

2. Install Expo CLI and EAS CLI:
   ```bash
   npm install -g expo-cli eas-cli
   ```

3. Extract the ZIP file (nfc-payment-system-export-v2.zip) to a folder on your computer

## Step 2: Update the API URL

Before building the app, update the API URL in `src/api/api.js` to point to your Replit app:

1. Open `src/api/api.js` in a text editor
2. Find this line:
   ```javascript
   const API_BASE_URL = 'https://nfc-payment-system.your-username.repl.co/api';
   ```
3. Replace with your actual Replit URL:
   ```javascript
   const API_BASE_URL = 'https://your-repl-name.your-username.repl.co/api';
   ```

## Step 3: Install Dependencies

Navigate to the extracted folder and install dependencies:

```bash
cd path/to/extracted/folder
npm install
```

## Step 4: Get Your Expo Project ID

1. If this is your first build, you'll need to get your Expo project ID
2. Run this command to create and configure your project:
   ```bash
   npx eas build:configure
   ```
3. Take note of the project ID generated (you'll need it for the next step)

## Step 5: Update app.json

1. Open `app.json` and update the projectId:
   ```json
   "extra": {
     "eas": {
       "projectId": "YOUR-PROJECT-ID-HERE"
     }
   }
   ```

## Step 6: Test in Expo Go

Before building, test your app in Expo Go:

1. Start the development server:
   ```bash
   npm start
   ```
2. Scan the QR code with the Expo Go app on your Android device
3. Verify the app loads and can connect to your Replit server

## Step 7: Build the APK

Now you can build the Android APK:

```bash
npx eas build -p android --profile preview
```

This will:
1. Upload your code to Expo's build servers
2. Build an Android APK in the cloud (no need for Android Studio!)
3. Provide a download link when complete

If you see a Gradle error, try:
```bash
npx eas build -p android --profile preview --clear-cache
```

## Step 8: Install and Test

1. Download the APK from the link provided in the build output
2. Transfer to your Android device and install it
3. Test the NFC functionality with your cards

## Troubleshooting

### Gradle Build Failed Error

If you encounter a "Gradle build failed" error:

1. Check that you've installed expo-build-properties:
   ```bash
   npm install expo-build-properties
   ```

2. Make sure you've updated the app.json and eas.json files with the correct configurations

3. Try building with the development profile:
   ```bash
   npx eas build -p android --profile development
   ```

### NFC Not Working

1. Ensure NFC is enabled in your Android settings
2. Check that your Android device supports NFC
3. Make sure you're using the installed APK, not Expo Go (full NFC support requires the native build)

### API Connection Issues

1. Double-check the API URL in src/api/api.js
2. Ensure your Replit server is running
3. Test if you can access the API endpoints in a browser

## Offline Mode

Your app includes offline capabilities:
- Customer data is cached when online
- Transactions can be processed offline
- Data syncs automatically when connection is restored

## Resources

- [Expo Documentation](https://docs.expo.dev/)
- [EAS Build Guide](https://docs.expo.dev/build/setup/)
- [NFC Manager for React Native](https://github.com/revtel/react-native-nfc-manager)