import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ActivityIndicator } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';

/**
 * A component to display offline status and provide sync controls
 * @param {Object} props Component props
 * @param {boolean} props.isOffline Whether the app is in offline mode
 * @param {boolean} props.syncing Whether the app is currently syncing
 * @param {number} props.pendingTransactions Number of pending transactions to sync
 * @param {Function} props.onSyncPress Function to call when the sync button is pressed
 * @returns {React.ReactElement} The offline indicator component
 */
const OfflineIndicator = ({ 
  isOffline, 
  syncing = false, 
  pendingTransactions = 0,
  onSyncPress 
}) => {
  if (!isOffline && pendingTransactions === 0) {
    return null; // Don't show anything when online and no pending transactions
  }

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <Icon 
          name={isOffline ? "cloud-off" : "cloud-done"} 
          size={20} 
          color={isOffline ? "#fff" : "#66bb6a"} 
        />
        <Text style={styles.text}>
          {isOffline 
            ? "Offline Mode" 
            : "Online"}
          {pendingTransactions > 0 && ` (${pendingTransactions} pending)`}
        </Text>
      </View>
      
      {pendingTransactions > 0 && !isOffline && (
        <TouchableOpacity 
          style={styles.syncButton} 
          onPress={onSyncPress}
          disabled={syncing}
        >
          {syncing ? (
            <ActivityIndicator size="small" color="#fff" />
          ) : (
            <View style={styles.syncContent}>
              <Icon name="sync" size={16} color="#fff" />
              <Text style={styles.syncText}>Sync</Text>
            </View>
          )}
        </TouchableOpacity>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#f44336',
    padding: 8,
    paddingHorizontal: 12,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  text: {
    color: '#fff',
    marginLeft: 8,
    fontSize: 14,
    fontWeight: '500',
  },
  syncButton: {
    backgroundColor: 'rgba(0, 0, 0, 0.2)',
    paddingVertical: 4,
    paddingHorizontal: 12,
    borderRadius: 4,
  },
  syncContent: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  syncText: {
    color: '#fff',
    marginLeft: 4,
    fontSize: 12,
    fontWeight: '500',
  },
});

export default OfflineIndicator;