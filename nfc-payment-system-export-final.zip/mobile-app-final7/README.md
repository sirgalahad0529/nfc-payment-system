# NFC Payment System Mobile App - Build Instructions (v10)

## Overview
This is version 10 of the NFC payment system mobile app, with a COMPLETE set of all required dependencies including network status monitoring. This version includes:

1. Added @react-native-community/netinfo for network status checking
2. Added zod and form validation dependencies (zod, react-hook-form, @hookform/resolvers)
3. All required navigation dependencies (@react-navigation/stack)
4. Properly formatted PNG assets created with ImageMagick
5. Explicit Gradle version 7.5.1 configuration for better compatibility
6. React Native 0.72.6 (compatible with selected Gradle version)

## Key Changes in v10
- Added missing @react-native-community/netinfo dependency for network status checking
- Added all form validation dependencies (zod, react-hook-form, @hookform/resolvers)
- Included all navigation dependencies (@react-navigation/stack)
- Fixed PNG format issues for Jimp compatibility
- Downgraded Gradle from 8.10 to 7.5.1 for better compatibility

## Setup Instructions

1. **Extract the archive**:
   ```
   unzip nfc-payment-system-export-v10.zip -d nfc-payment-app-v10
   cd nfc-payment-app-v10
   ```

2. **Install dependencies**:
   ```
   npm install
   ```
   Note: All dependencies are already included in package.json, no need to install anything else

3. **Configure EAS**:
   ```
   npx eas build:configure
   ```
   - When asked if you want to create a new project, answer "Yes"
   - Follow the prompts to create a new Expo project

## Build Instructions

1. **Recommended Build Command**:
   ```
   npx eas build -p android --profile preview --clear-cache
   ```

2. **If the above fails, try development profile**:
   ```
   npx eas build -p android --profile development
   ```

## Comprehensive Dependency List

This version includes ALL required dependencies:

1. **Navigation**: 
   - @react-navigation/native
   - @react-navigation/native-stack
   - @react-navigation/stack
   - react-native-gesture-handler
   - react-native-screens
   - react-native-safe-area-context

2. **Form Validation**:
   - zod
   - react-hook-form
   - @hookform/resolvers

3. **Storage & Network**:
   - @react-native-async-storage/async-storage
   - @react-native-community/netinfo
   - react-native-get-random-values
   - uuid

4. **UI & Components**:
   - react-native-paper
   - react-native-vector-icons

5. **NFC**:
   - react-native-nfc-manager

## Important Notes

- Do NOT upgrade Gradle or React Native versions unless you know what you're doing
- The package name is set to `com.nfcpayments.app` - change in app.json if needed
- This is a comprehensive build that should work on Expo's build system

## Troubleshooting

If you encounter build errors:

1. **Network Status Issues**: The @react-native-community/netinfo library is included
2. **Form Validation Issues**: All form validation modules are included
3. **Navigation Module Issues**: All navigation modules are included
4. **Gradle Version Issues**: Gradle version is set to 7.5.1
5. **Image Processing Errors**: PNG files are specifically formatted for Jimp

## Package Name

The application is configured with the package name `com.nfcpayments.app`.