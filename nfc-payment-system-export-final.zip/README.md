# NFC Payment System Mobile App - Build Instructions (v5)

## Overview
This is version 5 of the NFC payment system mobile app, specifically optimized to address Gradle build issues on MacBook Air M1 and other platforms. This version includes:

1. PNG assets instead of SVG files
2. Optimized Gradle configuration
3. Specific Android SDK versions
4. Memory settings for Gradle
5. Streamlined build process

## Setup Instructions

1. **Extract the archive**:
   ```
   unzip nfc-payment-system-export-v5.zip -d nfc-payment-app-v5
   cd nfc-payment-app-v5
   ```

2. **Install dependencies**:
   ```
   npm install
   npm install expo-build-properties
   ```

3. **Configure EAS**:
   ```
   npx eas build:configure
   ```
   - When asked if you want to create a new project, answer "Yes"
   - Follow the prompts to create a new Expo project

## Build Instructions

1. **Build for Android Development**:
   ```
   npx eas build -p android --profile development
   ```

2. **Build for Android Preview** (recommended):
   ```
   npx eas build -p android --profile preview --clear-cache
   ```

3. **Build for Android Production**:
   ```
   npx eas build -p android --profile production
   ```

## Troubleshooting

If you encounter any build errors:

1. **Check the Expo build logs** for specific error messages

2. **Try building with development profile** first:
   ```
   npx eas build -p android --profile development
   ```

3. **Try clearing all caches**:
   ```
   npx eas build -p android --profile preview --clear-cache
   ```

4. **Ensure PNG files** are properly placed in the assets folder:
   - icon.png
   - splash.png
   - adaptive-icon.png
   - favicon.png

5. **Ensure all dependencies are installed**:
   ```
   npm install
   npm install expo-build-properties
   ```

## Developing in Expo Go

If you want to develop using Expo Go before building:

```
npm start
```

Then scan the QR code with the Expo Go app on your Android device.

## Important Notes

- This version uses Gradle 7.5.1 which is compatible with the React Native Gradle plugin
- Android SDK is set to version 33 for better compatibility
- Gradle memory settings have been optimized for M1 processors
- PNG files are used instead of SVG files for compatibility

## Package Name

The application is configured with the package name `com.nfcpayments.app`. If you need to change this:

1. Open `app.json`
2. Change the `bundleIdentifier` value in the `ios` section
3. Change the `package` value in the `android` section

Use a unique package name following the reverse domain notation (e.g., com.yourcompany.appname).