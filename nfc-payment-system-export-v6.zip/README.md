# NFC Payment System Mobile App - Build Instructions (v6)

## Overview
This is version 6 of the NFC payment system mobile app, specifically optimized to resolve PNG image compatibility issues that were causing the Prebuild phase to fail. This version includes:

1. Properly formatted PNG assets created with ImageMagick (not converted from SVG)
2. Optimized Gradle configuration for MacBook Air M1
3. Specific Android SDK and Gradle version settings
4. Simplified build process

## Setup Instructions

1. **Extract the archive**:
   ```
   unzip nfc-payment-system-export-v6.zip -d nfc-payment-app-v6
   cd nfc-payment-app-v6
   ```

2. **Install dependencies**:
   ```
   npm install
   npm install expo-build-properties
   ```

3. **Configure EAS**:
   ```
   npx eas build:configure
   ```
   - When asked if you want to create a new project, answer "Yes"
   - Follow the prompts to create a new Expo project

## Build Instructions

1. **Recommended Build Command**:
   ```
   npx eas build -p android --profile preview --clear-cache
   ```

2. **If the above fails, try development profile**:
   ```
   npx eas build -p android --profile development
   ```

## Important Notes

- This version uses standard PNG files created directly with ImageMagick, not converted from SVG
- The PNG files are compatible with the Jimp image processing library used by Expo
- Package name is set to `com.nfcpayments.app` - change in app.json if needed
- Gradle version is set to 7.5.1 for better compatibility

## Package Name

The application is configured with the package name `com.nfcpayments.app`. If you need to change this:

1. Open `app.json`
2. Change the `bundleIdentifier` value in the `ios` section
3. Change the `package` value in the `android` section

Use a unique package name following the reverse domain notation (e.g., com.yourcompany.appname).