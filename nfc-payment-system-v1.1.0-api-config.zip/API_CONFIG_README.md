# API Configuration and Offline Functionality

## New Features in this Build

This build includes significant enhancements to the API configuration and offline capabilities of the NFC Payment System mobile application:

### 1. Configurable API Endpoints

- **Dynamic API URL Configuration**: Users can now configure the API endpoint directly from the settings screen, without requiring a rebuild of the application.
- **Simulated API Mode Toggle**: Switch between real API and simulated mode for testing without internet connectivity.
- **Persistence**: API configuration is saved and persists across app restarts.

### 2. Enhanced Offline Mode

- **Robust Network Detection**: Multi-layer approach to detect true internet connectivity beyond basic connection status.
- **Conservative Fallback**: Defaults to offline mode when connectivity is uncertain to ensure transaction processing can continue.
- **Seamless Transition**: Automatically transitions between online and offline modes based on network conditions.

### 3. Improved Documentation

- **Code Documentation**: Comprehensive comments explaining offline operation and API configuration.
- **Network Utilities**: Enhanced documentation of network detection mechanisms for future maintenance.
- **Clear Purpose**: Clarification that offline mode is designed for real-world operation in areas with erratic internet, not just for simulated testing.

## How to Use API Configuration

1. Navigate to the "Offline Settings" screen in the application.
2. Find the "API Configuration" section.
3. Enter your API URL (e.g., `https://your-server.replit.app/api`).
4. Toggle "Use Simulated API" based on your needs:
   - ON: Uses mock data for testing without a backend connection
   - OFF: Uses the specified API URL to connect to your real backend

## Offline Mode Operation

The application now handles offline transactions with improved reliability:

1. **Transaction Processing**: Continues to function when offline, storing transactions locally.
2. **Data Caching**: Automatically caches customer data for offline access.
3. **Synchronization**: When connectivity is restored, syncs pending transactions with the server.
4. **Visual Indicators**: Shows connection status with color-coded indicators.
5. **Manual Sync**: Provides a "Sync Now" button when there are pending transactions to synchronize.

## Implementation Details

- Network detection uses both NetInfo status and active internet connectivity tests
- API configuration is stored in AsyncStorage with other user settings
- The API module initializes with saved settings or defaults to simulated mode
- All API endpoints are now dynamically configured based on user settings