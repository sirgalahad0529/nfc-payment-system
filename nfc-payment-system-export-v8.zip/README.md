# NFC Payment System Mobile App - Build Instructions (v8)

## Overview
This is version 8 of the NFC payment system mobile app, fixing all dependency issues and ensuring a successful build. This version includes:

1. All required navigation dependencies (@react-navigation/stack)
2. Properly formatted PNG assets created with ImageMagick
3. Explicit Gradle version 7.5.1 configuration for better compatibility
4. React Native 0.72.6 (compatible with selected Gradle version)
5. Complete package.json with all necessary dependencies

## Key Changes in v8
- Added missing @react-navigation/stack dependency that caused the previous build to fail
- Included expo-build-properties dependency directly in package.json
- Added react-native-gesture-handler for navigation
- Fixed PNG format issues that caused "Unrecognised filter type - 160" errors
- Downgraded Gradle from 8.10 to 7.5.1 for better compatibility

## Setup Instructions

1. **Extract the archive**:
   ```
   unzip nfc-payment-system-export-v8.zip -d nfc-payment-app-v8
   cd nfc-payment-app-v8
   ```

2. **Install dependencies**:
   ```
   npm install
   ```
   Note: expo-build-properties is already included in package.json, no need to install separately

3. **Configure EAS**:
   ```
   npx eas build:configure
   ```
   - When asked if you want to create a new project, answer "Yes"
   - Follow the prompts to create a new Expo project

## Build Instructions

1. **Recommended Build Command**:
   ```
   npx eas build -p android --profile preview --clear-cache
   ```

2. **If the above fails, try development profile**:
   ```
   npx eas build -p android --profile development
   ```

## Important Notes

- Do NOT upgrade Gradle or React Native versions unless you know what you're doing
- The package name is set to `com.nfcpayments.app` - change in app.json if needed
- This build is specifically configured for compatibility with Expo's build system
- All navigation dependencies are properly included to avoid import errors

## Troubleshooting

If you encounter build errors:

1. **Navigation Module Issues**: All navigation modules are included in package.json
2. **Gradle Version Issues**: Make sure android/gradle/wrapper/gradle-wrapper.properties contains the correct version (7.5.1)
3. **React Native Plugin Errors**: Check the React Native version in package.json (should be 0.72.6)
4. **Image Processing Errors**: The PNG files included are specifically formatted to work with Jimp

## Package Name

The application is configured with the package name `com.nfcpayments.app`. If you need to change this:

1. Open `app.json`
2. Change the `bundleIdentifier` value in the `ios` section
3. Change the `package` value in the `android` section