# Export Instructions for NFC Payment System

This guide will walk you through the steps to export and install the NFC Payment System as a native Android app on your device to fully test the NFC functionality.

## Prerequisites

- An Android phone with NFC capabilities
- Expo Go app installed on your device (for development testing)
- Expo account (sign up at [expo.dev](https://expo.dev))
- Android Studio (only needed for advanced customization)

## Step 1: Update the API URL

Before building the app, make sure the API URL in `mobile-app/src/api/api.js` points to your Replit app. We've already updated this to:

```javascript
const API_BASE_URL = 'https://workspace.replit.app/api';
```

**IMPORTANT:** You need to replace `workspace` with your actual Replit app name. The correct format is:
- `https://{your-repl-name}.{your-username}.repl.co/api` 

For example:
- `https://nfc-payment-system.yourusername.repl.co/api`

## Step 2: Prepare App Assets

Before building, you need to convert the SVG icons to PNG format:

1. Install a tool like `svgexport` globally:
   ```bash
   npm install -g svgexport
   ```

2. Convert the SVG files to PNG:
   ```bash
   cd mobile-app
   svgexport assets/icon.svg assets/icon.png 1024:1024
   svgexport assets/adaptive-icon.svg assets/adaptive-icon.png 1024:1024
   svgexport assets/splash.svg assets/splash.png 1024:1024
   svgexport assets/favicon.svg assets/favicon.png 512:512
   ```

Alternatively, you can use any online SVG to PNG converter and upload the files manually to the `mobile-app/assets` directory.

## Step 3: Build the App (Quick Method - EAS Build)

The easiest way to build and install the app is using Expo's EAS Build service:

1. Install EAS CLI globally (if not already installed):
   ```bash
   npm install -g eas-cli
   ```

2. Log in to your Expo account:
   ```bash
   eas login
   ```

3. Navigate to the mobile app directory:
   ```bash
   cd mobile-app
   ```

4. Run the build command for Android:
   ```bash
   npm run build:android
   # OR directly: eas build -p android --profile preview
   ```

5. Follow the prompts in the terminal. EAS will build your app in the cloud and provide a download link for the APK.

6. Download the APK on your Android device and install it.

## Step 4: Local Development Testing (Alternative)

If you want to test changes quickly before building:

1. Install Expo Go from the Google Play Store on your Android device.

2. Start the Expo development server:
   ```bash
   cd mobile-app
   npm start
   ```

3. Scan the QR code with your Android device (using Expo Go).

4. **Note:** Web NFC API has limited support in Expo Go. Full NFC functionality will only be available in the native build.

## Step 5: Testing NFC Functionality

1. Open the installed app on your Android device
2. Go to Settings and ensure NFC scanning is enabled
3. Place an NFC card near your device's NFC reader
4. The app should detect the card and either:
   - Find an existing customer with that card ID, or
   - Prompt you to register a new customer

## Troubleshooting

### NFC Not Working

1. Ensure NFC is enabled in your Android settings (Settings → Connected devices → Connection preferences → NFC)
2. Make sure your phone supports NFC
3. Check the position of the NFC reader on your phone - it's typically on the back, but location varies by model
4. Some phones require the screen to be on and unlocked for NFC to work

### App Cannot Connect to API

1. Verify that your Replit app is running
2. Check that you've updated the API URL correctly in `mobile-app/src/api/api.js`
3. Try testing the API endpoint directly from your browser before running the app

### App Crashes on Launch

1. Check the app logs (through Android's developer options)
2. Ensure you have the latest version of the app installed
3. Try clearing the app cache in Android settings

## Offline Mode

Remember that your app has offline functionality built in:

1. When online, the app caches customer data and transaction history
2. If network connection is lost, the app will automatically switch to offline mode
3. Payments and balance reloads made offline are stored locally
4. When connection is restored, offline transactions are synchronized with the server

## Additional Resources

- [Expo Documentation](https://docs.expo.dev/)
- [EAS Build Documentation](https://docs.expo.dev/build/introduction/)
- [Web NFC API Documentation](https://developer.mozilla.org/en-US/docs/Web/API/NDEFReader)