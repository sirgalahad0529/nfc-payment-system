# Changelog

## v1.1.0 - API Configuration and Offline Improvements

### Added
- Configurable API endpoint in Settings screen
- API URL configuration that persists across app restarts
- Simulated API mode toggle in Settings
- Enhanced network detection for areas with erratic connectivity
- Improved offline transaction handling system
- Visual indicators to show online/offline/simulated API status
- Comprehensive documentation for offline mode operation

### Changed
- Network detection now uses multi-layered approach to better determine connectivity
- API module refactored to use dynamic configuration from settings
- Improved error handling for offline-to-online transitions
- Enhanced transaction sync mechanism for better reliability

### Documentation
- Added API_CONFIG_README.md with details on new features
- Enhanced inline code documentation for future maintainability
- Clarified purpose of offline mode for real-world usage in areas with poor connectivity

## v1.0.0 - Initial Release

### Features
- NFC card scanning capabilities
- Customer registration with NFC cards
- Payment processing with balance validation
- Balance reload functionality
- Transaction history and reporting
- Basic offline mode functionality
- Customer lookup by card ID