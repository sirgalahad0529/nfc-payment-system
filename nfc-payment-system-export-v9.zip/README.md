# NFC Payment System Mobile App - Build Instructions (v9)

## Overview
This is version 9 of the NFC payment system mobile app, fixing ALL dependency issues including form validation libraries. This version includes:

1. Added zod and form validation dependencies (zod, react-hook-form, @hookform/resolvers)
2. All required navigation dependencies (@react-navigation/stack)
3. Properly formatted PNG assets created with ImageMagick
4. Explicit Gradle version 7.5.1 configuration for better compatibility
5. React Native 0.72.6 (compatible with selected Gradle version)
6. Complete package.json with all necessary dependencies

## Key Changes in v9
- Added missing zod dependency that caused the previous build to fail
- Added react-hook-form and @hookform/resolvers dependencies
- Included all navigation dependencies (@react-navigation/stack)
- Fixed PNG format issues for Jimp compatibility
- Downgraded Gradle from 8.10 to 7.5.1 for better compatibility

## Setup Instructions

1. **Extract the archive**:
   ```
   unzip nfc-payment-system-export-v9.zip -d nfc-payment-app-v9
   cd nfc-payment-app-v9
   ```

2. **Install dependencies**:
   ```
   npm install
   ```
   Note: All dependencies are already included in package.json, no need to install anything else

3. **Configure EAS**:
   ```
   npx eas build:configure
   ```
   - When asked if you want to create a new project, answer "Yes"
   - Follow the prompts to create a new Expo project

## Build Instructions

1. **Recommended Build Command**:
   ```
   npx eas build -p android --profile preview --clear-cache
   ```

2. **If the above fails, try development profile**:
   ```
   npx eas build -p android --profile development
   ```

## Important Notes

- Do NOT upgrade Gradle or React Native versions unless you know what you're doing
- The package name is set to `com.nfcpayments.app` - change in app.json if needed
- All form validation and navigation dependencies are properly included
- This is a comprehensive build that should work on Expo's build system

## Troubleshooting

If you encounter build errors:

1. **Form Validation Issues**: All form validation modules (zod, react-hook-form) are included
2. **Navigation Module Issues**: All navigation modules are included in package.json
3. **Gradle Version Issues**: Make sure Gradle version is 7.5.1
4. **React Native Plugin Errors**: React Native version is 0.72.6
5. **Image Processing Errors**: PNG files are specifically formatted for Jimp

## Package Name

The application is configured with the package name `com.nfcpayments.app`.