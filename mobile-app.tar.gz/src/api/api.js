import { normalizeCardId } from '../utils/formatters';

// The base URL for the API
// IMPORTANT: Replace this with your actual production API URL before building the APK
// Example: https://your-backend-server.com/api or https://your-replit-app.replit.app/api
const API_BASE_URL = 'https://your-production-server.com/api';

// Helper function to handle API responses
const handleResponse = async (response) => {
  if (!response.ok) {
    // Try to get error details from the response
    try {
      const errorData = await response.json();
      throw new Error(errorData.message || 'API request failed');
    } catch (e) {
      throw new Error(`API request failed with status ${response.status}`);
    }
  }
  
  return response.json();
};

// Customer API functions
export const customerAPI = {
  // Get a customer by their card ID
  getByCardId: async (cardId) => {
    try {
      const normalizedCardId = normalizeCardId(cardId);
      const response = await fetch(`${API_BASE_URL}/customers/card/${normalizedCardId}`);
      return await handleResponse(response);
    } catch (error) {
      console.error('Error fetching customer by card ID:', error);
      throw error;
    }
  },
  
  // Get all customers
  getAll: async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/customers`);
      return await handleResponse(response);
    } catch (error) {
      console.error('Error fetching all customers:', error);
      throw error;
    }
  },
  
  // Register a new customer with a card
  register: async (customerData) => {
    try {
      // Ensure card ID is normalized
      if (customerData.cardId) {
        customerData.cardId = normalizeCardId(customerData.cardId);
      }
      
      const response = await fetch(`${API_BASE_URL}/customers`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(customerData),
      });
      
      return await handleResponse(response);
    } catch (error) {
      console.error('Error registering customer:', error);
      throw error;
    }
  },
  
  // Update a customer
  update: async (customerId, customerData) => {
    try {
      const response = await fetch(`${API_BASE_URL}/customers/${customerId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(customerData),
      });
      
      return await handleResponse(response);
    } catch (error) {
      console.error('Error updating customer:', error);
      throw error;
    }
  },
};

// Transaction API functions
export const transactionAPI = {
  // Process a payment
  processPayment: async (paymentData) => {
    try {
      // Ensure card ID is normalized
      if (paymentData.cardId) {
        paymentData.cardId = normalizeCardId(paymentData.cardId);
      }
      
      const response = await fetch(`${API_BASE_URL}/payments/process`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(paymentData),
      });
      
      return await handleResponse(response);
    } catch (error) {
      console.error('Error processing payment:', error);
      throw error;
    }
  },
  
  // Reload a customer's balance
  reloadBalance: async (reloadData) => {
    try {
      // Ensure card ID is normalized
      if (reloadData.cardId) {
        reloadData.cardId = normalizeCardId(reloadData.cardId);
      }
      
      const response = await fetch(`${API_BASE_URL}/payments/reload`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(reloadData),
      });
      
      return await handleResponse(response);
    } catch (error) {
      console.error('Error reloading balance:', error);
      throw error;
    }
  },
  
  // Get transaction history
  getHistory: async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/transactions`);
      return await handleResponse(response);
    } catch (error) {
      console.error('Error fetching transaction history:', error);
      throw error;
    }
  },
  
  // Get transaction details by ID
  getById: async (transactionId) => {
    try {
      const response = await fetch(`${API_BASE_URL}/transactions/${transactionId}`);
      return await handleResponse(response);
    } catch (error) {
      console.error('Error fetching transaction details:', error);
      throw error;
    }
  },
  
  // Get transactions by customer ID
  getByCustomerId: async (customerId) => {
    try {
      const response = await fetch(`${API_BASE_URL}/customers/${customerId}/transactions`);
      return await handleResponse(response);
    } catch (error) {
      console.error('Error fetching customer transactions:', error);
      throw error;
    }
  },
  
  // Get transactions by card ID
  getByCardId: async (cardId) => {
    try {
      const normalizedCardId = normalizeCardId(cardId);
      const response = await fetch(`${API_BASE_URL}/cards/${normalizedCardId}/transactions`);
      return await handleResponse(response);
    } catch (error) {
      console.error('Error fetching card transactions:', error);
      throw error;
    }
  },
};