import { useState, useEffect, useCallback } from 'react';
import NfcManager, { NfcTech, Ndef } from 'react-native-nfc-manager';
import { normalizeCardId } from '../utils/formatters';

// Initialize NFC manager
NfcManager.start();

export const useNFC = () => {
  const [isScanning, setIsScanning] = useState(false);
  const [error, setError] = useState(null);
  const [supported, setSupported] = useState(false);

  // Check if NFC is supported when the hook is first used
  useEffect(() => {
    const checkSupport = async () => {
      try {
        const isSupported = await NfcManager.isSupported();
        setSupported(isSupported);
        
        if (isSupported) {
          await NfcManager.start();
        }
      } catch (ex) {
        console.warn('NFC check failed', ex);
        setSupported(false);
      }
    };
    
    checkSupport();
    
    // Cleanup
    return () => {
      if (isScanning) {
        cancelScan();
      }
    };
  }, []);

  // Function to start NFC scanning
  const startScan = useCallback(async (callback) => {
    try {
      setIsScanning(true);
      setError(null);
      
      if (!supported) {
        throw new Error('NFC is not supported on this device');
      }
      
      // Register tag event listener
      await NfcManager.registerTagEvent();
      
      // Set up tag discovered listener
      NfcManager.setEventListener(NfcTech.Ndef, async (event) => {
        try {
          if (event && event.tag && event.tag.id) {
            // Get the tag ID (UID)
            const tagId = event.tag.id;
            
            // Normalize the ID to ensure consistent format
            const normalizedId = normalizeCardId(tagId);
            
            if (callback) {
              callback({ cardId: normalizedId });
            }
            
            // Clean up after successful scan
            await NfcManager.unregisterTagEvent();
            setIsScanning(false);
          }
        } catch (err) {
          console.error('Error processing NFC tag event:', err);
          setError(err.message || 'Error reading NFC tag');
        }
      });
      
    } catch (ex) {
      console.error('Error starting NFC scan:', ex);
      setError(ex.message || 'Failed to start NFC scan');
      setIsScanning(false);
      cancelScan();
    }
  }, [supported]);

  // Function to cancel scanning
  const cancelScan = useCallback(async () => {
    try {
      setIsScanning(false);
      await NfcManager.unregisterTagEvent();
      NfcManager.setEventListener(NfcTech.Ndef, null);
    } catch (ex) {
      console.warn('Error cancelling NFC scan:', ex);
    }
  }, []);

  // Function to simulate a scan for testing
  const simulateScan = useCallback((callback) => {
    // Generate a random card ID
    const randomId = (Math.floor(Math.random() * 10000000000)).toString(16).toUpperCase();
    const simulatedCardId = normalizeCardId(randomId);
    
    // Simulate a delay in scanning
    setTimeout(() => {
      if (callback) {
        callback({ cardId: simulatedCardId });
      }
    }, 1500);
  }, []);

  return {
    isScanning,
    error,
    supported,
    startScan,
    cancelScan,
    simulateScan
  };
};